import { Component, OnInit } from '@angular/core';
import { employee } from './employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {   

  empList : employee[] = [    
    {
      employeeId : 1,
      firstName: "bob",
      lastName: "john",
      salary: 500,
      dob: new Date(1997, 0O5, 0O5, 17, 23, 42, 11),
      email: "bob@gmail.com"
    },
    {
      employeeId : 2,
      firstName: "abc",
      lastName: "stephen",
      salary: 800,
      dob: new Date(1996, 0O1, 0O2, 17, 23, 42, 11),
      email: "abc@gmail.com"
    },
    {
      employeeId : 3,
      firstName: "mormont",
      lastName: "lyana",
      salary: 600,
      dob: new Date(2001, 0o2, 0o4, 17, 23, 42, 11),
      email: "mormont@gmail.com"
    }
  ]

  showEdit = false;

  constructor() {}

  ngOnInit(): void {
  }

  editEmp(){
    this.showEdit = !this.showEdit;
  }

  updateEmp(){
    this.showEdit = false;
  }

}
