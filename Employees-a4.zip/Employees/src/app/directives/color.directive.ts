import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
    selector: '[highlight]'    
})
export class HighlightDirecctive{
    constructor(private el: ElementRef) {
    }
    @Input('myHighlight') highlightColor: null;
    @HostListener('mouseenter') onMouseEnter() {
      this.highlight('green');
      this.el.nativeElement.style.color = 'white';
    }      
       
    private highlight(color: string) {
      this.el.nativeElement.style.backgroundColor = color;
    }
    @HostListener('mouseleave') onMouseLeave() {
      this.highlight('white');
      this.el.nativeElement.style.color = 'black';
    }
}