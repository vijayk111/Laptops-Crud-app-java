import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})

@Injectable()
export class FetchAllEmpService {
  constructor() {
  }
}