export interface IEmployee{
    id : number;
    employee_name : string;
    employee_salary : number;
    employee_age : string;
    profile_image : string;
}