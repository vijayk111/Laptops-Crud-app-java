import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee2';
import { FetchAllEmpService } from './newemployee.component.service';

@Component({
  selector: 'app-newemployee',
  templateUrl: './newemployee.component.html',
  styleUrls: ['./newemployee.component.css']
})
export class NewemployeeComponent implements OnInit {

  empList : IEmployee[];

  constructor(private service : FetchAllEmpService) {
    this.empList = [];
   }

  ngOnInit(){ 
    this.service.getEmployees().subscribe(
      (data)=> {
          this.empList = data.data;
      });  
  }
}
