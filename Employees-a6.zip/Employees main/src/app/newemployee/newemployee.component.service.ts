import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IEmployee } from './employee2';
import { map } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})

@Injectable()
export class FetchAllEmpService {

  constructor(private httpClient:HttpClient) { }

  getEmployees() : Observable<any>{
      return this.httpClient.get("http://dummy.restapiexample.com/api/v1/employees");
  }  
}