import { Component, OnInit } from '@angular/core';
import { employee } from './employee';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {   

  emp : employee = {
    employeeId : 1,
    firstName: "bob",
    lastName: "john",
    salary: 500,
    dob: new Date(1997, 0O5, 0O5, 17, 23, 42, 11),
    email: "abc@gmail.com"
  }

  showEdit = false;

  constructor() {}

  ngOnInit(): void {
  }

  editEmp(){
    this.showEdit = !this.showEdit;
  }

  updateEmp(){
    this.showEdit = false;
  }

}
